var express = require('express');
var mysql = require('mysql2');
var cors = require('cors');
const nodemailer = require("../sendmailer");
var bodyparser = require('body-parser');

const UserModal = require("../model/userModel")

const userController={

async createUser(req,res){

  let userData = req.body;

  // console.log(req.body);

  let[User]=await


   UserModal.CreateUser(userData)

    if(User.affectedRows>0){
      console.log(User);
      res.send({
        message: "Register is created successfully."
      });
      console.log(userData);
      nodemailer.sendConfirmationEmail(
        userData.username,
        userData.email
 );
    }
    else{
      console.log("Error");
    }
  },

//loginuser
    async loginUser(req,res){

      let userData = req.body;
    
      // console.log(req.body);
    
      let[User]=await
    
    
       UserModal.loginUser(userData)
    
        if(User.affectedRows>0){
          console.log(User);
          res.send({
            message: "log in  successfully."
          });
          console.log(userData);
          nodemailer.sendConfirmationEmail(
            userData.username,
            userData.email
     );
        }
        else{
          console.log("Error");
        }
      },
      async getAllUser(req,res){

  console.log("Hello");

  let getAllUser = await UserModal.GetAllUser();
  if(getAllUser[0].length){
    console.log("Done");
    res.send(getAllUser[0]);
  }
  else{
    console.log("Error");
  }
},
async getUser(req,res){

  let data ={"user":req.params.id};
  let getinUser = await UserModal.getUser(data);

  if(getinUser){
    res.send(getinUser[0]);
  }

},
async updateUser(req,res){

  

  let data ={"user_id":req.params.id,"user_name":req.body.user_name};

  console.log(data);
  let getinUser = await UserModal.updateUser(data);

  if(getinUser){
    res.send(getinUser[0]);
  }

},

 
}


module.exports=userController;

